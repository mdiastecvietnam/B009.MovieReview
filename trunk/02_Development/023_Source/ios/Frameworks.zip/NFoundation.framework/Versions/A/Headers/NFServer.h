//
//  NFServer.h
//  Himawari School
//
//  Created by Nguyen Duc Hiep on 5/28/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NFDefines.h"

NF_EXTERN NSString *const kNFErrorDomainServer;
NF_EXTERN NSInteger const kNFErrorCodeInvalidAddress;


@protocol NFServer<NSObject>

- (void)request:(NSString *)address method:(NSString *)method paras:(NSDictionary *)paras completion:(void (^)(NSError *error, NSData *data))completion;

@end

@interface NFServer: NSObject<NFServer>

NF_SINGLETON_DECLARE(instancetype, sharedServer);

@property (nonatomic, assign) NSTimeInterval timeOutInterval;

@end
