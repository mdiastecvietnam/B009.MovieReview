//
//  NFDevice.h
//  NFoundation
//
//  Created by Nguyen Duc Hiep on 4/9/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NFDefines.h"

NF_EXTERN NSString *const kNFWifiInfoSSID;
NF_EXTERN NSString *const kNFWifiInfoBSSID;

NF_EXTERN NSString *const kNFLocationLatitude;
NF_EXTERN NSString *const kNFLocationLongitude;

// Error
NF_EXTERN NSString *const kNFErrorDomainDevice;
NF_EXTERN NSString *const kNFErrorDomainDeviceLocation;
NF_EXTERN NSInteger const kNFErrorCodeDeviceJustDennied;
NF_EXTERN NSInteger const kNFErrorCodeDeviceDennied;
NF_EXTERN NSInteger const kNFErrorCodeDeviceRestricted;

@protocol NFDevice<NSObject>

- (NSDictionary *) currentWifiInfo;

- (void) readLocationWithCompletionHandler: (void (^)(NSDictionary *location, NSError *error)) handler;

- (BOOL) canOpenSettings;
- (BOOL) openSettings;
- (BOOL) tryOpenSettings;

- (BOOL) canOpenURL: (NSString *) URLString;
- (BOOL) openURL: (NSString *) URLString;
- (BOOL) tryOpenURL: (NSString *) URLString;

@end
