//
//  NFDefineSynch.h
//  NFoundation
//
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#ifndef NFoundation_NFDefineSynch_h
#define NFoundation_NFDefineSynch_h

#define NF_TRY_CALL(handler, ...) if (handler != nil) handler(__VA_ARGS__);;

#endif
