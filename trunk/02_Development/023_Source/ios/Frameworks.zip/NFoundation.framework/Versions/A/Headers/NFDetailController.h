//
//  NFDetailController.h
//  NFoundation
//
//  Created by Nguyen Duc Hiep on 3/17/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import "NFController.h"
#import "NFListController.h"

@protocol NFDetailController<NFController>

@property (nonatomic, weak) id<NFListController> listController;

@property (nonatomic, strong) id item;
@property (nonatomic, readonly) NSInteger index;
@property (nonatomic, readonly) id leadItem;
@property (nonatomic, readonly) id trailItem;

- (void) moveNext;
- (void) refresh;
- (void) movePrevious;

@end

@interface NFDetailController: NFController<NFDetailController>

@end
