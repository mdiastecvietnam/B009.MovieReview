//
//  NFSharableView.h
//  NFoundation
//
//  Created by Nguyen Duc Hiep on 4/14/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import "NFView.h"

@protocol NFSharableView<NFView>

- (void)shareItems:(NSArray *)items;

@end
