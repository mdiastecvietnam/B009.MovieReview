//
//  NFDefineEtcs.h
//  NFoundation
//
//  Created by Nguyen Duc Hiep on 4/27/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#ifndef NFoundation_NFDefineEtcs_h
#define NFoundation_NFDefineEtcs_h

#define NF_SINGLETON_DECLARE(type, x) \
+ (type) x;

#define NF_SINGLETON_IMPLEMENTATION(iType, x) \
+ (iType *) x \
{\
    static iType *x = nil;\
    @synchronized(self)\
    {\
        if (x == nil)\
        {\
            x = [[iType alloc] init];\
        }\
    }\
    return x;\
}

#define NF_ARE_OBJ_EQUALS(lv, rv) ((lv) == (rv) || [lv isEqual:rv])

#endif
