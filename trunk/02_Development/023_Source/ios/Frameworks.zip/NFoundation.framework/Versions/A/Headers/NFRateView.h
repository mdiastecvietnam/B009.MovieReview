//
//  NFRateView.h
//  NFoundation
//
//  Created by Nguyen Duc Hiep on 4/10/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import "NFView.h"

@protocol NFRateView<NFView>

@property (nonatomic, assign, getter = isReadonly) BOOL readonly; // default NO
@property (nonatomic, assign, getter = isNotRated) BOOL notRated; // default YES
@property (nonatomic, assign) float rate;

@end
