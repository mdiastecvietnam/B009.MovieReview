//
//  NFSearchRefreshListController.h
//  NFoundation
//
//  Created by Nguyen Duc Hiep on 3/10/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import "NFSearchController.h"
#import "NFRefreshController.h"
#import "NFListController.h"

@protocol NFSearchRefreshListController <NFSearchController, NFRefreshController, NFListController>

- (NSArray *) sourceItems;
- (void) setSourceItems: (NSArray *) items;
- (void) setSourceItem: (id) item;

- (NSInteger) indexOfSourceItem: (id) item;
- (id) sourceItemAtIndex: (NSInteger) index;

- (void) resetSourceItem: (id) item;

@end

@interface NFSearchRefreshListController: NFController<NFSearchRefreshListController>

@end

@protocol NFSearchRefreshListControllerDelegate <NFSearchControllerDelegate, NFRefreshControllerDelegate, NFListControllerDelegate>

@end