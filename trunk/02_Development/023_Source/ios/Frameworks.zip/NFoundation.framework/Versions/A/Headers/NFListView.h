//
//  NFListView.h
//  NFoundation
//
//  Created by Nguyen Duc Hiep on 3/4/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import "NFView.h"

@protocol NFListView<NFView>

- (void)reloadWithAnimated:(BOOL)animated;
- (void)reloadItemAtIndex:(NSInteger)index animated:(BOOL)animated;
- (void)insertItemAtIndex:(NSInteger)index animated:(BOOL)animated;
- (void)deleteItemAtIndex:(NSInteger)index animated:(BOOL)animated;
- (NSIndexSet *)visibleItemIndexes;

@end
