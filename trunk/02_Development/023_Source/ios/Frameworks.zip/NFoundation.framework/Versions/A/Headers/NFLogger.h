//
//  NFLogger.h
//  NFoundation
//
//  Created by Nguyen Duc Hiep on 4/10/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NFDefineEtcs.h"

@interface NFLogger: NSObject

NF_SINGLETON_DECLARE(NFLogger *, logger)

- (void) log: (NSString *) text;

@end
