//
//  NFSearchController.h
//  NFoundation
//
//  Created by Nguyen Duc Hiep on 3/10/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import "NFController.h"

@protocol NFSearchController <NFController>

@property (nonatomic, strong) NSString *keyDelimiter;
- (void) textChanged;

- (BOOL) testItem: (id) item;
- (NSArray *) testItems: (NSArray *) items;

@end

@interface NFSearchController: NFController<NFSearchController>

@end

@protocol NFSearchControllerDelegate <NFControllerDelegate>

@optional
- (NSArray *) searchController: (id<NFSearchController>) searchController searchValuesForItem: (id) item;

@end
