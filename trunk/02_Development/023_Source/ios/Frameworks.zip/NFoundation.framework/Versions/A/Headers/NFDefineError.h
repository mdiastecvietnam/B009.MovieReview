//
//  NFDefineError.h
//  NFoundation
//
//  Created by Nguyen Duc Hiep on 5/6/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#ifndef NFoundation_NFDefineError_h
#define NFoundation_NFDefineError_h

#define NF_ERROR(domain, code, parent) NFError(domain, code, __FILE__, __LINE__, parent)

#endif
