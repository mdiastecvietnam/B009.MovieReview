//
//  NSData+NFoundation.h
//  NFoundation
//
//  Created by Nguyen Duc Hiep on 4/14/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData(NFoundation)

- (NSString *)hexDigest;

- (NSData *)MD5;

- (NSData *)SHA256;

+ (NSData *)randomDataWithSize:(NSUInteger)length;

- (NSData *) AES256EncryptWithKey:(NSData *)key iv:(NSData *)iv;
- (NSData *) AES256DecryptWithKey:(NSData *)key iv:(NSData *)iv;

@end
