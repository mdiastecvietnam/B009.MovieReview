//
//  NFController.h
//  NFoundation
//
//  Created by Nguyen Duc Hiep on 3/10/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import "NFView.h"

@protocol NFControllerDelegate <NSObject>

@end

@protocol NFController <NSObject>

@property (nonatomic, weak) id<NFControllerDelegate> delegate;
@property (nonatomic, weak) id<NFView> view;

@end

@interface NFController: NSObject<NFController>

@end
