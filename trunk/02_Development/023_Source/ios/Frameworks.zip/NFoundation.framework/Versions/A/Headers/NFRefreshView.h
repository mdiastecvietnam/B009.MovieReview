//
//  NFRefreshView.h
//  NFoundation
//
//  Created by Nguyen Duc Hiep on 3/11/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import "NFView.h"

@protocol NFRefreshView<NFView>

@property (nonatomic, assign, getter = isRefreshing) BOOL refreshing;

- (void)performRefreshing;

@end
