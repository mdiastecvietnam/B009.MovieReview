//
//  NFDefineIf.h
//  NFoundation
//
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#ifndef NFoundation_NFDefineIf_h
#define NFoundation_NFDefineIf_h

#define NF_RETURN_IF(b) if (b) return;;
#define NF_RETURN_VALUE_IF(b, v) if (b) return (v);;
#define NF_RETURN_IF_NIL(o) NF_RETURN_IF(o == nil)
#define NF_RETURN_VALUE_IF_NIL(o, v) NF_RETURN_VALUE_IF(o == nil, v)

#define NF_SET_IF_GREATER(lv, rv) if (lv > rv) lv = rv;;
#define NF_SET_IF_LESSER(lv, rv) if (lv < rv) lv = rv;;
#define NF_SET_IF(b, lv, rv) if (b) lv = rv;;
#define NF_SET_IF_NOT_NULL(p, v) NF_SET_IF(p != NULL, *p, v)
#define NF_SET_IF_NOT_EQUALS(lv, rv) NF_SET_IF(lv != rv, lv, rv)
#define NF_SET_IF_NOT_OBJECT_EQUALS(lv, rv) NF_SET_IF(![lv equals: rv], lv, rv)

#endif
