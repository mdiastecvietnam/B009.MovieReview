//
//  NFDefineExterning.h
//  NFoundation
//
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#ifndef NFoundation_NFDefineExterning_h
#define NFoundation_NFDefineExterning_h

#if defined(__cplusplus)
#define NF_EXTERN extern "C"
#else
#define NF_EXTERN extern
#endif

#endif
