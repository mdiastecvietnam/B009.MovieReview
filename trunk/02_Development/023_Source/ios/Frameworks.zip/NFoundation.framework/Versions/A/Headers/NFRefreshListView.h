//
//  NFRefreshListView.h
//  NFoundation
//
//  Created by Nguyen Duc Hiep on 3/16/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import "NFRefreshView.h"
#import "NFListView.h"

@protocol NFRefreshListView<NFView>

@property (nonatomic, readonly) id<NFRefreshView> refreshView;
@property (nonatomic, readonly) id<NFListView> listView;

@end
