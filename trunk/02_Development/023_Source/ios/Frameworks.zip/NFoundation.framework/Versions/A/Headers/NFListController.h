//
//  NFListController.h
//  NFoundation
//
//  Created by Nguyen Duc Hiep on 3/10/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import "NFListView.h"
#import "NFController.h"

@protocol NFListController<NFController>

@property (nonatomic, readonly) NSInteger numberOfItems;

- (NSArray *)items;
- (id)itemAtIndex:(NSInteger)index;

- (NSInteger)indexOfItem:(id)item;
- (void)searchItem:(id)item leadIndex:(NSInteger *) leadIndex trailIndex:(NSInteger *)trailIndex;

- (void)addItem:(id)item;
- (void)insertItem:(id)item atIndex:(NSInteger)index;

- (void)setItems:(NSArray *)items;
- (void)setItem:(id)item;
- (void)setItem:(id)item selectionKey:(NSString *)selectionKey;
- (void)resetItem:(id)item;

- (void)reload;
- (void)reloadItem:(id)item;
- (void)reloadItemAtIndex:(NSInteger)index;

- (BOOL)item:(id)lv equals:(id)rv;

- (void)spareMemory;

@end

@interface NFListController: NFController<NFListController>

@end

@protocol NFListControllerDelegate<NFControllerDelegate>

@optional
- (NSComparisonResult)listController:(id<NFListController>)listController item:(id)leftItem comparesItem:(id)rightItem;
- (void)listController:(id<NFListController>)listController item:(id)item applyToItem:(id)appliedItem selectionKey:(NSString *)selectionKey;
- (void)listController:(id<NFListController>)listController spareMemoryItem:(id)item;

@end
