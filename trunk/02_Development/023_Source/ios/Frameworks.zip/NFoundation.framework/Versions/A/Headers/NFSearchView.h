//
//  NFSearchView.h
//  NFoundation
//
//  Created by Nguyen Duc Hiep on 3/16/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import "NFView.h"

@protocol NFSearchView<NFView>

@property (nonatomic, readonly) NSString *text;

@end
