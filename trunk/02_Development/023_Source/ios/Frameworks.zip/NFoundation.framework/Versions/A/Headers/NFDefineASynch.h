//
//  NFDefineASynch.h
//  NFoundation
//
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#ifndef NFoundation_NFDefineASynch_h
#define NFoundation_NFDefineASynch_h

#define NF_ASYNC_DECLARE_CALLER_QUEUE(handler) NSOperationQueue *__weak callerQueue = (handler != nil) ? [NSOperationQueue currentQueue] : nil;
#define NF_ASYNC_CALL(handler,...) [callerQueue addOperationWithBlock: ^{ handler(__VA_ARGS__); }];
#define NF_ASYNC_TRY_CALL(handler,...) if (handler != nil) NF_ASYNC_CALL(handler, __VA_ARGS__);;
#define NF_ASYNC_CURRENT_CALL(handler,...) [[NSOperationQueue currentQueue] addOperationWithBlock:^{ handler(__VA_ARGS__); }];
#define NF_ASYNC_CURRENT_TRY_CALL(handler,...) if (handler != nil) NF_ASYNC_CURRENT_CALL(handler, __VA_ARGS__);;

#endif
