//
//  NFDefineView.h
//  NFoundation
//
//  Created by Nguyen Duc Hiep on 4/5/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#ifndef NFoundation_NFDefineView_h
#define NFoundation_NFDefineView_h

#define view(type, controller) ((type)controller.view)
#define controller(type, view) ((type)view.controller)

#endif
