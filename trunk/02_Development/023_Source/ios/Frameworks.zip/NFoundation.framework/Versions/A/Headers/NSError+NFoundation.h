//
//  NSError+NFoundation.h
//  NFoundation
//
//  Created by Nguyen Duc Hiep on 4/8/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSError(NFoundation)

- (BOOL) isKindOfDomain: (NSString *) domain;
- (BOOL) isKindOfDomain: (NSString *) domain code: (NSInteger) code;

@end
