//
//  NFSingleController.h
//  WifiShare
//
//  Created by Nguyen Duc Hiep on 4/14/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import "NFController.h"

@protocol NFSingleController<NFController>

@end

@interface NFSingleController: NFController<NFSingleController>

@end
