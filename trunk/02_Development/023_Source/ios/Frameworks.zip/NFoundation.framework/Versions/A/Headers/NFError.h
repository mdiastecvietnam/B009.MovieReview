//
//  NFError.h
//  NFoundation
//
//  Created by Nguyen Duc Hiep on 5/6/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NFDefines.h"

NF_EXTERN NSInteger const kNFErrorCodeUnknown;
