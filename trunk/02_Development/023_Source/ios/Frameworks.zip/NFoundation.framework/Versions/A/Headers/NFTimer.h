//
//  NFTimer.h
//  NFoundation
//
//  Created by Nguyen Duc Hiep on 5/27/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@class NFTimer;

@protocol NFTimerDelegate<NSObject>

- (void)firedByTimer:(NFTimer *)timer;

@end

@interface NFTimer: NSObject

@property (atomic, weak) id<NFTimerDelegate> delegate; // default: nil
@property (atomic, strong) void (^handler)(); // default: nil
@property (atomic, assign) NSTimeInterval delayInterval; // negative, default: 1
@property (atomic, assign) BOOL repeats; // default: YES
@property (atomic, assign, getter = isActive) BOOL active; // default: NO
@property (atomic, assign) NSTimeInterval tolerance; // negative, default 1e-2
@property (atomic, weak) NSOperationQueue *operationQueue; // default: nil

- (instancetype)initWithDelayInterval:(NSTimeInterval)delayInterval repeats:(BOOL)repeats operationQueue:(NSOperationQueue *)operationQueue delegate:(id<NFTimerDelegate>)delegate;
- (instancetype)initWithDelayInterval:(NSTimeInterval)delayInterval repeats:(BOOL)repeats operationQueue:(NSOperationQueue *)operationQueue handler:(void (^)())handler;

- (void) reset;
- (void) exceed;

@end
