//
//  NFRefreshController.h
//  NFoundation
//
//  Created by Nguyen Duc Hiep on 3/11/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import "NFController.h"

@protocol NFRefreshController<NFController>

- (void) refreshingChanged;

@end

@interface NFRefreshController: NFController<NFRefreshController>

@end

@protocol NFRefreshControllerDelegate<NFControllerDelegate>

@optional
- (void) refreshController: (id<NFRefreshController>) refreshController refreshingWithCompletionHandler: (void (^)()) handler;

@end
