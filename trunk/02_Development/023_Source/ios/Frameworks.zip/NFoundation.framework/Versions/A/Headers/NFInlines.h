//
//  NFInlines.h
//  NFoundation
//
//  Created by Nguyen Duc Hiep on 4/10/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#ifndef NFoundation_NFInlines_h
#define NFoundation_NFInlines_h

#import "NFDefines.h"

static inline void NFAddObjectIfNotNil(NSMutableArray *array, id value)
{
    NF_RETURN_IF_NIL(value);
    [array addObject: value];
}

static inline void NFSetObjIfNotNil(NSMutableDictionary *dict, id<NSCopying> key, id value)
{
    NF_RETURN_IF_NIL(value);
    dict[key] = value;
}

static inline BOOL NFAreObjEquals(id lv, id rv)
{
    return NF_ARE_OBJ_EQUALS(lv, rv);
}

static inline NSArray *NFArrayWithObjectsIfNotNil(int count, ...)
{
    NSMutableArray *array = [NSMutableArray arrayWithCapacity:count];
    va_list ap;
    va_start(ap, count);
    for (int i = 0; i < count; i++) {
        NFAddObjectIfNotNil(array, va_arg(ap, id));
    }
    va_end(ap);
    return array;
}

static inline NSError *NFError(NSString *domain, NSInteger code, const char *file, int line, id parent)
{
    return [NSError errorWithDomain:domain code:code userInfo:(parent == nil ? @{@"file": @(file), @"line": @(line)} : @{@"file": @(file), @"line": @(line), @"parent": parent})];
}

#endif
