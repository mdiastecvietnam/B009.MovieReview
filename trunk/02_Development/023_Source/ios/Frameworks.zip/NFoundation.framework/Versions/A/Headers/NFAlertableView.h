//
//  NFAlertableView.h
//  NFoundation
//
//  Created by Nguyen Duc Hiep on 4/14/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import "NFView.h"

@protocol NFAlertableView<NFView>

- (void)alertWithTitle:(NSString *)title message:(NSString *)message selections:(NSArray *)selections completionHandler:(void (^)(NSInteger))handler;

@end
