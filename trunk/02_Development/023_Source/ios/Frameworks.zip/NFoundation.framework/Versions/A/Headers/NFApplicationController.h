//
//  NFApplicationController.h
//  NFTouch
//
//  Created by Nguyen Duc Hiep on 4/2/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import "NFSingleController.h"

@protocol NFApplicationController<NFSingleController>

- (void)applicationDidFinishLaunch;

@end

@interface NFApplicationController: NFSingleController<NFApplicationController>

@end
