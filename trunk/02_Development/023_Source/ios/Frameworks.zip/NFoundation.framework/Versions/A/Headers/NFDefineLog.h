//
//  NFDefineLog.h
//  NFoundation
//
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#ifndef NFoundation_NFDefineLog_h
#define NFoundation_NFDefineLog_h

#ifdef DEBUG

#define NF_LOG_STRING(logger, str) [logger log: str];

#define NF_TRY_LOG_ERROR(logger, error)\
if (error != nil)\
{\
NF_LOG_ERROR(logger, error);\
}

#define NF_LOGGER_DECLARE(l) NFLogger*__weak logger = l;

#else

#define NF_LOG_STRING(logger, str)
#define NF_TRY_LOG_ERROR(logger, error)
#define NF_LOGGER_DECLARE(l)

#endif

#define NF_LOG_ERROR_STRING(logger, s) NF_LOG_STRING(logger, ([NSString stringWithFormat: @"Error: %@ at line %d file %s", s, __LINE__, __FILE__]))

#define NF_LOG_ERROR(logger, error) NF_LOG_ERROR_STRING(logger, ([error localizedDescription] != nil) ? [error localizedDescription] : @"Unknown Error")

#define NF_LOGGER_LOG_STRING(str) NF_LOG_STRING(logger, str)
#define NF_LOGGER_LOG_ERROR_STRING(s) NF_LOG_ERROR_STRING(logger, s)
#define NF_LOGGER_LOG_ERROR(error) NF_LOG_ERROR(logger, error)
#define NF_LOGGER_TRY_LOG_ERROR(error) NF_TRY_LOG_ERROR(logger, error)

#endif
