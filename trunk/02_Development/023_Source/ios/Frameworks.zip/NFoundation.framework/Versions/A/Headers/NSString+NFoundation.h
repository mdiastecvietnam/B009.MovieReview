//
//  NSString+NFoundation.h
//  NFoundation
//
//  Created by Nguyen Duc Hiep on 4/22/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString(NFoundation)

- (NSString *)MD5WithEncoding:(NSStringEncoding)encoding;
- (NSString *)MD5;

- (NSString *)SHA256WithEncoding:(NSStringEncoding)encoding;
- (NSString *)SHA256;

- (NSString *)base64AES256EncryptWithKey:(NSString *)key iv:(NSString *)iv encoding:(NSStringEncoding)encoding;
- (NSString *)base64AES256EncryptWithKey:(NSString *)key iv:(NSString *)iv;

- (NSString *)base64AES256DecryptWithKey:(NSString *)key iv:(NSString *)iv encoding:(NSStringEncoding)encoding;
- (NSString *)base64AES256DecryptWithKey:(NSString *)key iv:(NSString *)iv;

@end
