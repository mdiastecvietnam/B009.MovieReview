//
//  NFTViews.h
//  NFTouch
//
//  Created by Nguyen Duc Hiep on 3/16/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#ifndef NFTouch_NFTViews_h
#define NFTouch_NFTViews_h

#import "NFTApplicationDelegate.h"
#import "NFTCollectionView.h"
#import "NFTTableView.h"
#import "NFTSearchView.h"
#import "NFTRefreshView.h"
#import "NFTRefreshCollectionView.h"
#import "NFTRefreshTableView.h"
#import "NFTSearchRefreshTableView.h"
#import "NFTRateView.h"

#endif
