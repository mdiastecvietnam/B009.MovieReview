//
//  NFTLINEActivity.h
//  NFTouch
//
//  Created by Nguyen Duc Hiep on 4/14/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NFTLINEActivity: UIActivity

- (instancetype) init;
- (instancetype) initWithPerformIfLineNotInstalled: (BOOL) performIfLineNotInstalled;

@end
