//
//  NFTKeyboardObserver.h
//  NFTouch
//
//  Created by Nguyen Duc Hiep on 4/27/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import <NFoundation/NFoundation.h>

typedef NS_ENUM(NSInteger, NFTKeyboardStatus)
{
    NFTKeyboardStatusDisappearing,
    NFTKeyboardStatusDisappeared,
    NFTKeyboardStatusAppearing,
    NFTKeyboardStatusAppeared
};

@interface NFTKeyboardObserver: NSObject

NF_SINGLETON_DECLARE(instancetype, sharedObserver);

@property (nonatomic, readonly) NFTKeyboardStatus status;

- (void) addKeyboardWillAppearHandler: (void (^)()) handler;
- (void) addKeyboardDidAppearHandler: (void (^)()) handler;
- (void) addKeyboardWillDisappearHandler: (void (^)()) handler;
- (void) addKeyboardDidDisappearHandler: (void (^)()) handler;

@end
