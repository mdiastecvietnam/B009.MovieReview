//
//  UILabel+NFTouch.h
//  NFTouch
//
//  Created by Nguyen Duc Hiep on 4/19/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel(NFTouch)

- (CGFloat) heightThatFitWidth: (CGFloat) width;

@end
