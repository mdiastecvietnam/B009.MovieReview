//
//  NFTDefineLocalizable.h
//  NFTouch
//
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#ifndef NFTouch_NFTDefineLocalizable_h
#define NFTouch_NFTDefineLocalizable_h

#define NFTLocalizedString(key) NSLocalizedStringFromTable(key, @"NFTLocalizable", nil)

#endif
