//
//  NFTouch.h
//  NFTouch
//
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import <NFoundation/NFoundation.h>

#pragma mark - Version info

FOUNDATION_EXPORT double NFTouchVersionNumber;
FOUNDATION_EXPORT const unsigned char NFTouchVersionString[];

#pragma mark - NFTouch

#import <NFTouch/NFT3rdLibraries.h>
#import <NFTouch/NFTDefines.h>
#import <NFTouch/NFTViews.h>
#import <NFTouch/NFTExtensions.h>
#import <NFTouch/NFTEtcs.h>
