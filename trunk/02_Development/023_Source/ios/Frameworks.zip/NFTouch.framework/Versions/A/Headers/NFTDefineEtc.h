//
//  NFTDefineEtc.h
//  NFTouch
//
//  Created by Nguyen Duc Hiep on 3/16/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#ifndef NFTouch_NFDefineEtc_h
#define NFTouch_NFDefineEtc_h

#pragma mark - NFTApplicationDelegate

#define NFT_APPLICATION_DELEGATE_INIT_IMPLEMENTATION(cT) \
- (instancetype) init\
{\
    self = [super init];\
    if (self != nil)\
    {\
        self.applicationController = [[cT alloc] init];\
    }\
    return self;\
}

#pragma mark - Etc

#define NFT_DEPRECATED_IOS(iOSDep) NS_DEPRECATED_IOS(7_0, iOSDep)

#endif
