//
//  UIView+NFTouch.h
//  NFTouch
//
//  Created by Nguyen Duc Hiep on 3/16/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NFTDefines.h"

@interface UIView(NFTouch)

- (void) setConstraint: (NSLayoutConstraint *) constraint NFT_DEPRECATED_IOS(8_0);
- (void) resetConstraint: (NSLayoutConstraint *) constraint NFT_DEPRECATED_IOS(8_0);
- (void) layoutConstraint: (NSLayoutConstraint *) constraint setActive: (BOOL) active;

- (BOOL) trySetIsFirstResponder: (BOOL) isFirstResponder;
- (void) trySetIsFirstResponder: (BOOL) isFirstResponder completionHandler: (void (^)(BOOL completion)) handler;
- (UIView *) firstResponder;
- (UIView *) firstResponderable;

@end
