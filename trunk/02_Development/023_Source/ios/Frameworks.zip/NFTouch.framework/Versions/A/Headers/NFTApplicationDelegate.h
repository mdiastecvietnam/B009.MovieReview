//
//  NFTApplicationDelegate.h
//  NFTouch
//
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <NFoundation/NFoundation.h>

NF_EXTERN NSString *const kNFNotificationNameApplicationWillResignActive;
NF_EXTERN NSString *const kNFNotificationNameApplicationDidEnterBackground;
NF_EXTERN NSString *const kNFNotificationNameApplicationWillEnterForeground;
NF_EXTERN NSString *const kNFNotificationNameApplicationDidBecomeActive;
NF_EXTERN NSString *const kNFNotificationNameApplicationWillTerminate;

@interface NFTApplicationDelegate: UIResponder <UIApplicationDelegate, NFSingleView>

@property (nonatomic, strong) UIWindow *window;
@property (nonatomic, strong) id<NFApplicationController> applicationController;

@end
