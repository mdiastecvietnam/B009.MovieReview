//
//  NFTPresenter.h
//  NFTouch
//
//  Created by Nguyen Duc Hiep on 4/17/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NFTPresenter: NSObject

+ (void) viewController: (UIViewController *) viewController causalView: (UIView *) causalView presentViewController: (UIViewController *) viewControllerToPresent animated: (BOOL) animated completion: (void (^)(void)) completion;

+ (void) viewController: (UIViewController *) viewController causalBarButtonItem: (UIBarButtonItem *) causalBarButtonItem presentViewController: (UIViewController *) viewControllerToPresent animated: (BOOL) animated completion: (void (^)(void)) completion;

+ (void) viewController: (UIViewController *) viewController causalRect: (CGRect) causalRect presentViewController: (UIViewController *) viewControllerToPresent animated: (BOOL) animated completion: (void (^)(void)) completion;

@end
