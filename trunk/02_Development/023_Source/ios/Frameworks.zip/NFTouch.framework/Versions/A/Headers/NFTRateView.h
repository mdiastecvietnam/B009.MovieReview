//
//  NFTRateView.h
//  NFTouch
//
//  Created by Nguyen Duc Hiep on 4/2/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <NFoundation/NFoundation.h>

@protocol NFTRateViewDelegate;

@interface NFTRateView: UIView<NFRateView>

@property (nonatomic, weak) IBOutlet id<NFTRateViewDelegate> delegate;

@end

@protocol NFTRateViewDelegate<NSObject>

- (void) rateView: (NFTRateView *) rateView rateChanged: (CGFloat) rate;

@end
