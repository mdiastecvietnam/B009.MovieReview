//
//  NFTActivityItemSourceSubject.h
//  NFTouch
//
//  Created by Nguyen Duc Hiep on 4/23/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NFTActivityItemSourceSubject: NSObject<UIActivityItemSource>

- (instancetype) initWithSubject: (NSString *) subject activityTypes: (NSArray *) activityTypes;

@end
