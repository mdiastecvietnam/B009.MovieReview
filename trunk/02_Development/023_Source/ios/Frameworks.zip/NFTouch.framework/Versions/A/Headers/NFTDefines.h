//
//  NFTDefines.h
//  NFTouch
//
//  Created by Nguyen Duc Hiep on 4/10/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#ifndef NFTouch_NFTDefines_h
#define NFTouch_NFTDefines_h

#import "NFTDefineLocalizable.h"
#import "NFTDefineEtc.h"

#endif
