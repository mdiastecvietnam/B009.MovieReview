//
//  UIViewController+NFTouch.h
//  NFTouch
//
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController(NFTouch)

- (BOOL) pushViewController: (UIViewController *) viewController animated: (BOOL) animated;
- (BOOL) popViewControllerAnimated: (BOOL) animated;
- (NSArray *) popToViewController: (UIViewController *) viewController animated: (BOOL) animated;

- (BOOL) tryOpenURLString: (NSString *) URLString;

@end
