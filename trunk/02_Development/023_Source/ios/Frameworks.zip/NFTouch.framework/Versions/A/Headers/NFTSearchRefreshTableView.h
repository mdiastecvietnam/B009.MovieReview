//
//  NFSearchRefreshTableView.h
//  NFTouch
//
//  Created by Nguyen Duc Hiep on 3/16/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import "NFTRefreshTableView.h"

@interface NFTSearchRefreshTableView: NFTRefreshTableView<NFSearchRefreshListView>
@end

@protocol NFTSearchRefreshTableViewDelegate<UITableViewDelegate>

- (void) searchRefreshTableViewTextChanged: (NFTSearchRefreshTableView *) searchRefreshTableView;

@end
