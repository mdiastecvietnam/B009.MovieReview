//
//  NFRefreshTableView.h
//  NFTouch
//
//  Created by Nguyen Duc Hiep on 3/16/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import "NFTTableView.h"
#import "NFTRefreshView.h"

@interface NFTRefreshTableView: NFTTableView<NFRefreshListView>

@property (nonatomic, readonly) NFTRefreshView *nftRefreshView;

@end
