//
//  NFTViewController.h
//  NFTouch
//
//  Created by Nguyen Duc Hiep on 4/6/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <NFoundation/NFoundation.h>

@interface NFTViewController: UIViewController<NFSingleView>

- (instancetype) initWithDefaultNibName;
- (instancetype) initWithController: (id<NFController>) controller;
- (void) alertWithTitle: (NSString *) title message: (NSString *) message selections: (NSArray *) selections completionHandler: (void (^)(NSInteger buttonIndex)) handler;
- (void) animateWithAnimations: (void (^)()) animations completion: (void (^)(BOOL finished)) completion;

@end
