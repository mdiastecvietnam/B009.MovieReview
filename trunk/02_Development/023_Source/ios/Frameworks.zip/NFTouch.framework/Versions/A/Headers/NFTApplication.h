//
//  NFTApplication.h
//  NFTouch
//
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import <NFoundation/NFoundation.h>
#import <UIKit/UIKit.h>

NF_EXTERN NSString *const kNFNotificationNameApplicationDidReceiveEvent;
NF_EXTERN NSString *const kNFNotificationUserInfoEvent;

@interface NFTApplication: UIApplication

@end
