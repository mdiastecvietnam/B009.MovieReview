//
//  NFTImagePicker.h
//  NFTouch
//
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NFTImagePicker: NSObject

- (void) pickImageWithCausalRect: (CGRect) causalRect viewController: (UIViewController *) viewController completionHandler: (void (^)(UIImage *image)) completionHandler;
- (void) pickImageWithCausalView: (UIView *) causalView viewController: (UIViewController *) viewController completionHandler: (void (^)(UIImage *image)) completionHandler;
- (void) pickImageWithCausalBarButtonItem: (UIBarButtonItem *) barButtonItem viewController: (UIViewController *) viewController completionHandler: (void (^)(UIImage *image)) completionHandler;

@end
