//
//  NFMFlow.h
//  NFMock
//
//  Created by Nguyen Duc Hiep on 7/8/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import <NFoundation/NFoundation.h>

@protocol NFMFlow<NSObject>

- (void)excute:(void (^)())handler;
- (void)excute:(void (^)())handler completion:(void (^)())completion;
- (void)waitForHandler:(BOOL (^)())handler;
- (void)waitForTimeout:(NSTimeInterval)timeout;
- (void)waitForHandler:(BOOL (^)())handler timeout:(NSTimeInterval)timeout;

@end

@interface NFMFlow: NSObject<NFMFlow>

@end
