//
//  NFMFlowFlagHolder.h
//  NFMock
//
//  Created by Nguyen Duc Hiep on 7/9/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import "NFMFlow.h"
#import "NFMFlagHolder.h"

@protocol NFMFlowFlagHolder<NFMFlow, NFMFlagHolder>

- (void)waitForFlag:(NSString *)flagKey;
- (void)waitForFlag:(NSString *)flagKey timeout:(NSTimeInterval)timeout;
- (void)waitForFlag:(NSString *)flagKey holder:(NFMFlagHolder *)holder;
- (void)waitForFlag:(NSString *)flagKey holder:(NFMFlagHolder *)holder timeout:(NSTimeInterval)timeout;

@end

@interface NFMFlowFlagHolderStrategy: NSObject<NFMFlowFlagHolder>

- (instancetype)initWithFlow:(NFMFlow *)flow flagHolder:(NFMFlagHolder *)flagHolder;

@end
