//
//  NFMSingleView.h
//  NFMock
//
//  Created by Nguyen Duc Hiep on 4/15/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import "NFMView.h"

@interface NFMSingleView: NFMView<NFSingleView>

@end
