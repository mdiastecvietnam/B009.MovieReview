//
//  NFMServer.h
//  NFMock
//
//  Created by Nguyen Duc Hiep on 7/6/15.
//  Copyright (c) 2015 Neodata Co., Ltd, LTD. All rights reserved.
//

#import <NFoundation/NFoundation.h>

@interface NFMServer1: NSObject<NFServer>

@property (nonatomic, readonly) NSString *address;
@property (nonatomic, readonly) NSString *method;
@property (nonatomic, readonly) NSDictionary *paras;

- (void)responseWithData:(NSData *)data error:(NSError *)error;

@end
