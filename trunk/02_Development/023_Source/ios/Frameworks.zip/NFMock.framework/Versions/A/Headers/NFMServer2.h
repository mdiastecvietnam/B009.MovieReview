//
//  NFMServer2.h
//  NFMock
//
//  Created by Nguyen Duc Hiep on 7/6/15.
//  Copyright (c) 2015 Neodata Co., Ltd, LTD. All rights reserved.
//

#import <NFoundation/NFoundation.h>

@interface NFMServer2: NSObject<NFServer>

- (void)reset;
- (void)addRequest:(NSString *)address method:(NSString *)method paras:(NSDictionary *)paras error:(NSError *)error data:(NSData *)data delay:(NSTimeInterval)delay count:(NSUInteger)count;

@end
