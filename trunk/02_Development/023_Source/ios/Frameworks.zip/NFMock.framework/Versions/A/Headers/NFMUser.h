//
//  NFMUser.h
//  NFMock
//
//  Created by Nguyen Duc Hiep on 5/12/15.
//  Copyright (c) 2015 MDI ASTEC VN Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NFMUser: NSObject

- (void)execute:(void (^)())handler;
- (BOOL)waitFor:(BOOL (^)())conditioner timeout:(NSTimeInterval)timeout;
- (void)wait;
@end
