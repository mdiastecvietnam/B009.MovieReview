//
//  NFMock.h
//  NFMock
//
//  Created by Nguyen Duc Hiep on 4/10/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import <NFoundation/NFoundation.h>

#pragma mark - Version info

FOUNDATION_EXPORT double NFMockVersionNumber;
FOUNDATION_EXPORT const unsigned char NFMockVersionString[];

#pragma mark - NFMock

#import <NFMock/NFMViews.h>
#import <NFMock/NFMEtcs.h>
