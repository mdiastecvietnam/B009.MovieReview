//
//  NFMFlagHolder.h
//  NFMock
//
//  Created by Nguyen Duc Hiep on 7/8/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import <NFoundation/NFoundation.h>

@protocol NFMFlagHolder<NSObject>

- (BOOL)flagForKey:(NSString *)key;
- (void)setFlagForKey:(NSString *)key;
- (void)resetFlagForKey:(NSString *)key;

@end

@interface NFMFlagHolder: NSObject<NFMFlagHolder>

@end
