//
//  NFMTestClient.h
//  NFMock
//
//  Created by Nguyen Duc Hiep on 7/9/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import "NFMFlowFlagHolder.h"

@interface NFMTestClient: NFMFlow<NFMFlowFlagHolder>

@end
