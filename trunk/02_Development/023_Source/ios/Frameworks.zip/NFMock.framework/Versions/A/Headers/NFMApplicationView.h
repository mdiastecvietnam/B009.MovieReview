//
//  NFMApplicationView.h
//  NFMock
//
//  Created by Nguyen Duc Hiep on 5/13/15.
//  Copyright (c) 2015 Neodata Co., Ltd. All rights reserved.
//

#import "NFMSingleView.h"
#import "NFMFlowFlagHolder.h"

@interface NFMApplicationView: NFMSingleView<NFMFlowFlagHolder>

@end
